package gimnasio321;

import java.util.Objects;


public abstract class Entrenador {
    
    private int legajo;
    private String nombre;
    private String apellido; 
    private int anioDeIngreso;

    public Entrenador(int legajo, String nombre, String apellido, int anioDeIngreso) {
        this.legajo = legajo;
        this.nombre = nombre;
        this.apellido = apellido;
        this.anioDeIngreso = anioDeIngreso;
    }
    
 
    
    @Override
    public int hashCode() {
        int hash = 5;
        return hash;
    }

    @Override   
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Entrenador other = (Entrenador) obj;
        if (this.legajo != other.legajo) {
            return false;
        }
        return Objects.equals(this.legajo, other.legajo);
    }

    @Override
    public String toString() {
        return "legajo=" + legajo + ", nombre=" + nombre + ", apellido=" + apellido + ", anioDeIngreso=" + anioDeIngreso;
    }
    
    
    
    
    public abstract double calcularSueldo();
    
    
    public String nombreCompleto(){
       return this.nombre + " " + this.apellido;
    }

    public int getAnioDeIngreso() {
        return anioDeIngreso;
    }
      
        
        
        
}
    
