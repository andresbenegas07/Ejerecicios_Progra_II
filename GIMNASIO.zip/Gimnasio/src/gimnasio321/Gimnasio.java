package gimnasio321;
import java.util.ArrayList;


public class Gimnasio {
    private String nombre;
    private ArrayList<Entrenador> entrenadores;
    
    
    public Gimnasio(String nombre) {
        this.nombre = nombre;
        this.entrenadores = new ArrayList<>();
    }
    
    
    public void mostrarSueldos(){
        for(Entrenador entrenador: entrenadores){
            entrenador.calcularSueldo();
        }
    }
    
    public Entrenador entrenadorConMasClientes(){
        return null;
    }
    
    public void agregarEntrenador(Entrenador entrenador){
        if (!validarEntrenador(entrenador)){
            this.entrenadores.add(entrenador);
        
        }
        
    }
    
    private boolean validarEntrenador(Entrenador entrenador){
        return this.entrenadores.contains(entrenador);
    }
    
}
