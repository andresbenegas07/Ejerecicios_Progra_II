package gimnasio321;


public class Gimnasio321 {

    public static void main(String[] args) {
        
        
    }
    
}
