package gimnasio321;


public class PersonalTrainer extends Entrenador {
    
   private double sueldoMinimo; 
   private int numeroDeClientes;  
   private double montoPorCliente;

   public PersonalTrainer(double sueldoMinimo, int numeroDeClientes, double montoPorCliente, int legajo, String nombre, String apellido, int anioDeIngreso) {
        super(legajo, nombre, apellido, anioDeIngreso);
        this.sueldoMinimo = sueldoMinimo;
        this.numeroDeClientes = numeroDeClientes;
        this.montoPorCliente = montoPorCliente;
    }

    @Override
    public double calcularSueldo() {
        double sueldoCalculado = this.numeroDeClientes * this.montoPorCliente;
        return sueldoCalculado > this.sueldoMinimo ? sueldoCalculado : this.sueldoMinimo;
    }

    @Override
    public String toString() {
        return "Datos del PersonalTrainer" +super.toString() + "sueldoMinimo=" + sueldoMinimo + ", numeroDeClientes=" + numeroDeClientes + ", montoPorCliente=" + montoPorCliente;
    }
   
   
   
   
    
    
}
