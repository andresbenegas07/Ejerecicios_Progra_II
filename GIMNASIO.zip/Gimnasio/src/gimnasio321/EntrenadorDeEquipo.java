package gimnasio321;

import java.time.LocalDate;

public class EntrenadorDeEquipo extends Entrenador {
   private double sueldoFijo;
   private static final int MAX_ANTIGUEDAD=6;
   private static final int MIN_ANTIGUEDAD=3;
   private static final double MAX_DESCUENTO=0.12;
   private static final double MIN_DESCUENTO=0.04;

    public EntrenadorDeEquipo(double sueldoFijo, int legajo, String nombre, String apellido, int anioDeIngreso) {
        super(legajo, nombre, apellido, anioDeIngreso);
        this.sueldoFijo = sueldoFijo;
    }

    @Override
    public double calcularSueldo() {
        
        return this.sueldoFijo + porcentajeDeAumento();
    }
    
    private double porcentajeDeAumento(){
        int antiguedad = calcularAntiguedad();
        double aumento = 0;
        
        if(antiguedad > MAX_ANTIGUEDAD){
            aumento = sueldoFijo * MAX_DESCUENTO;
        }else if(antiguedad > MIN_ANTIGUEDAD){
            aumento = sueldoFijo * MIN_DESCUENTO;
        }
        
        return aumento;
    }
    
    
    private int calcularAntiguedad(){
        int antiguedad = LocalDate.now().getYear() - getAnioDeIngreso();
        return antiguedad;
    }

    @Override
    public String toString() {
        return "Datos del Entrenador de equipo"+ super.toString() + "sueldoFijo=" + sueldoFijo;
    }
   
    
    
    
}
