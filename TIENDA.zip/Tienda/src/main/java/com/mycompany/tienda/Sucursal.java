package com.mycompany.tienda;


import java.util.ArrayList;
import java.util.Objects;


public class Sucursal {
    
    private String nombreSucursal;
    private ArrayList<Dispositivos> dispositivo;
    
    public Sucursal(String nombreSucursal){
        this.nombreSucursal = nombreSucursal;
        this.dispositivo = new ArrayList<Dispositivos>();
    }
    
    
    public void listarDispositivos(){
        for(Dispositivos dispositivo: dispositivo){
            System.out.println(dispositivo);
        }
    }
    
    
    private void dispositivosPorTipo(Tipo tipo){
    }
    
    private void borrarDispositivo(){
    }
    
    
    public void agregarDispositivo(Dispositivos dispositivo){
       validarDispositivo(dispositivo);
       this.dispositivo.add(dispositivo);
    }
    
    private void validarDispositivo(Dispositivos dispositivo){
        if(dispositivo == null){
            throw new IllegalArgumentException("No se puede agregar DISPOSITIVO INVALIDO");
        }
        
    }
    
    public boolean compararNombre(String nombre){
        return this.nombreSucursal.equals(nombre);
    }
    

    @Override
    public int hashCode() {
        return Objects.hash(nombreSucursal);
    }
        
    @Override
    public boolean equals(Object o){
        if((o == null) || !(o instanceof Sucursal s)){
        return false;
        } 
        return nombreSucursal.equals(s.nombreSucursal);
     }
    
    
    
    
    }
