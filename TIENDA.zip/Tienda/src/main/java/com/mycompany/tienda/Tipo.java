package com.mycompany.tienda;



public enum Tipo {
    TELEFONO,
    COMPUTADORA,
    TABLET
}
