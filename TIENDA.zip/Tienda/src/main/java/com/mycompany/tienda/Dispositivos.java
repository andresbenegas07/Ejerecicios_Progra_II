package com.mycompany.tienda;



public class Dispositivos {
    
    private String id;
    private double precio;
    private Tipo tipo;
    
    public Dispositivos(String id, double precio, Tipo tipo) {
        this.id = id;
        this.precio = precio;
        this.tipo = tipo;
    }

    @Override
    public String toString() {
        return "Dispositivos{" + "id=" + id + ", precio=" + precio + ", tipo=" + tipo + '}';
    }
       
    
    
            
            
            
            
}
