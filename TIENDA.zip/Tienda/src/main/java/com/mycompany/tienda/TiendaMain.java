package com.mycompany.tienda;

public class TiendaMain {

    public static void main(String[] args) {
        
        Tienda  tienda = new Tienda("MusiTienda");
        
        Sucursal sucursal1 = new Sucursal("Sucursal Martinez");
        Sucursal sucursal2 = new Sucursal("Sucursal Las Lomitas");
        
       
        tienda.agregarSucursal(sucursal1);
        tienda.agregarSucursal(sucursal2);
        
        Dispositivos dispositivo3 = new Dispositivos("a412366",100, Tipo.COMPUTADORA);
        tienda.agregarDispositivoASucursal(sucursal1, dispositivo3);
        
        Dispositivos dispositivo1 = new Dispositivos("a4123",1000, Tipo.COMPUTADORA);
        Dispositivos dispositivo2 = new Dispositivos("a41234",17800, Tipo.TABLET);
        
        tienda.listarDispositivos();
       
    }
}
 