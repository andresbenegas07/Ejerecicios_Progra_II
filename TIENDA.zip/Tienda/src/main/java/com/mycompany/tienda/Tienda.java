package com.mycompany.tienda;

import java.util.ArrayList;


public class Tienda {
        private String nombre;
        private ArrayList<Sucursal> sucursales;

    public Tienda(String nombre) {
        this.nombre = nombre;
        this.sucursales = new ArrayList<>();
    }
        

    public void listarDispositivos(){
        for(Sucursal sucursal: sucursales){
            sucursal.listarDispositivos();
        }
    }    
    
    public void agregarDispositivoASucursal(Sucursal sucursal, Dispositivos dispositivo){
        validarSucursal(sucursal);
        sucursal.agregarDispositivo(dispositivo);
        
    }
    
    
    public void agregarSucursal(Sucursal sucursal){
        validarSucursal(sucursal);
        sucursales.add(sucursal);
          
    }
    
    private void validarSucursal(Sucursal sucursal){
        if(sucursal== null || sucursales.contains(sucursal)){
            throw new IllegalArgumentException("No se puede agregar sucursal VACIA o REPETIDA");
        }
        
    }
    
    
    /*private Sucursal buscarSucursal(String nombre){
        
        int indice = 0;
        while()
        
    */
    
    
}
